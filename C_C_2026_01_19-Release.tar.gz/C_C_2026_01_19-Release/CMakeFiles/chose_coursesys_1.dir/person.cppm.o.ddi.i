# 0 "/root/demo/chose_coursesys_1/person.cppm"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/root/demo/chose_coursesys_1/person.cppm"
export module domain.person;

import std;

export class Person {
private:
    std::string id;
    std::string name;
    int age;
    std::string gender;

public:
    Person(std::string id, std::string name, int age = 18, std::string gender = "未知");
    virtual ~Person() = default;


    std::string getId() const { return id; }
    std::string getName() const { return name; }
    int getAge() const { return age; }
    std::string getGender() const { return gender; }


    void setName(const std::string& n) { name = n; }
    void setAge(int a) { age = a; }
    void setGender(const std::string& g) { gender = g; }
};

Person::Person(std::string id, std::string name, int age, std::string gender)
    : id(std::move(id)), name(std::move(name)), age(age), gender(std::move(gender)) {}
