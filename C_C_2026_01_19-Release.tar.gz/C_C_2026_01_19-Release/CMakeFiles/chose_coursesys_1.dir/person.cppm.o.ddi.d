CMakeFiles/chose_coursesys_1.dir/person.cppm.o.ddi: \
 /root/demo/chose_coursesys_1/person.cppm /usr/include/stdc-predef.h
