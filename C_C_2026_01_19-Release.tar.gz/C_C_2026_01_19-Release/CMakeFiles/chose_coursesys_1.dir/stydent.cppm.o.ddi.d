CMakeFiles/chose_coursesys_1.dir/stydent.cppm.o.ddi: \
 /root/demo/chose_coursesys_1/stydent.cppm /usr/include/stdc-predef.h
