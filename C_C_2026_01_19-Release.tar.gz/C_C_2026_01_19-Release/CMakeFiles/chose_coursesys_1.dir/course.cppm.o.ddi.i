# 0 "/root/demo/chose_coursesys_1/course.cppm"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/root/demo/chose_coursesys_1/course.cppm"
export module domain.course;

import std;

using std::string;
using std::move;
using std::vector;
using std::move;

export class Course {
private:
    string courseId;
    string courseName;
    int maxCapacity;
    int currentCapacity;

public:
    Course(string id, string name, int maxCap);
    string getCourseId() const;
    string getCourseName() const;
    int getMaxCapacity() const;
    int getCurrentCapacity() const;
    bool isFull() const;
    bool enrollStudent();
    bool dropStudent();
    int getRemainingCapacity() const ;
    bool setCapacity(int newCapacity);
};

Course::Course(string id, string name, int maxCap)
    : courseId(move(id)), courseName(move(name)),
      maxCapacity(maxCap), currentCapacity(0)
{
    if (maxCap <= 0) {
        throw std::invalid_argument("课程容量必须大于0");
    }
}

string Course::getCourseId() const { return courseId; }


string Course::getCourseName() const { return courseName; }


int Course::getMaxCapacity() const { return maxCapacity; }


int Course::getCurrentCapacity() const { return currentCapacity; }


bool Course::isFull() const { return currentCapacity >= maxCapacity; }



bool Course::enrollStudent() {
    if (isFull()) {
        return false;
    }
    currentCapacity++;
    return true;
}


bool Course::dropStudent() {
    if (currentCapacity <= 0) {
        return false;
    }
    currentCapacity--;
    return true;
}


int Course::getRemainingCapacity() const {
    return maxCapacity - currentCapacity;
}


bool Course::setCapacity(int newCapacity) {
    if (newCapacity < currentCapacity) {
        return false;
    }
    maxCapacity = newCapacity;
    return true;
}
