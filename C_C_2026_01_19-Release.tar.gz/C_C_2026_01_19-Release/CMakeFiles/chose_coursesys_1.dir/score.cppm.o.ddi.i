# 0 "/root/demo/chose_coursesys_1/score.cppm"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/root/demo/chose_coursesys_1/score.cppm"
export module domain.score;

import std;

using std::string;
using std::move;
using std::vector;
using std::move;

export class Score {
private:
    string studentId;
    string courseId;
    float score;

public:
    Score(string sid, string cid, float s);
    string getStudentId() const;
    string getCourseId() const;
    float getScore() const { return score; }
    void setScore(float s);
    string getGrade() const;
};


string Score::getGrade() const {
    if (score >= 90) return "A";
    if (score >= 80) return "B";
    if (score >= 70) return "C";
    if (score >= 60) return "D";
    return "F";
}


void Score::setScore(float s) {
    if (s < 0 || s > 100) {
        throw std::invalid_argument("成绩必须在0-100之间");
    }
    score = s;
}


string Score::getCourseId() const { return courseId; }


string Score::getStudentId() const { return studentId; }
Score::Score(string sid, string cid, float s)
    : studentId(move(sid)), courseId(move(cid)), score(s) {
    if (score < 0 || score > 100) {
        throw std::invalid_argument("成绩必须在0-100之间");
    }
}
