CMakeFiles/chose_coursesys_1.dir/registrar.cppm.o.ddi: \
 /root/demo/chose_coursesys_1/registrar.cppm /usr/include/stdc-predef.h
