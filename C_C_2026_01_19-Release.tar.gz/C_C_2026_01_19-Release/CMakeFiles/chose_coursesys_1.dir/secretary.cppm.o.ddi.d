CMakeFiles/chose_coursesys_1.dir/secretary.cppm.o.ddi: \
 /root/demo/chose_coursesys_1/secretary.cppm /usr/include/stdc-predef.h
