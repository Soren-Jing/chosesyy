CMakeFiles/chose_coursesys_1.dir/score.cppm.o.ddi: \
 /root/demo/chose_coursesys_1/score.cppm /usr/include/stdc-predef.h
