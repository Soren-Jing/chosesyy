# 0 "/root/demo/chose_coursesys_1/registrar.cppm"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/usr/include/stdc-predef.h" 1 3 4
# 0 "<command-line>" 2
# 1 "/root/demo/chose_coursesys_1/registrar.cppm"
export module domain.registrar;

import std;
import domain.student;
import domain.course;
import domain.teacher;
import domain.score;
import domain.person;
import database;
using std::string;
using std::vector;
using std::unique_ptr;
using std::unordered_map;
using std::print;
using std::move;

export class Registrar {
private:
    unordered_map<string, unique_ptr<Student>> students;
    unordered_map<string, unique_ptr<Course>> courses;
    unordered_map<string, unique_ptr<Teacher>> teachers;

public:
    void addStudent(unique_ptr<Student> student);
    void addCourse(unique_ptr<Course> course);
    void addTeacher(unique_ptr<Teacher> teacher);
    bool registerCourse(const string& studentId, const string& courseId);
    bool dropCourse(const string& studentId, const string& courseId);
    vector<const Course*> getStudentCourses(const string& studentId) const ;
    vector<const Student*> getCourseStudents(const string& courseId) const;

    const unordered_map<string, unique_ptr<Course>>& getAllCourses() const ;
    const unordered_map<string, unique_ptr<Student>>& getAllStudents() const ;
    bool printStudentRecord(const std::string& studentId) const;

    const Person* findPerson(const string& id) const;

    void displayAllRegistrations() const {
            std::println("\n=== 学生选课总览 ===");
            for (const auto& [studentId, student] : students) {
                std::print("学生 {} ({}, 年龄:{}, 性别:{}): ",
                          student->getName(), studentId,
                          student->getAge(), student->getGender());
                auto courses = getStudentCourses(studentId);
                if (courses.empty()) {
                    std::print("未选课");
                } else {
                    for (const auto* course : courses) {
                        std::print("{} ", course->getCourseName());
                    }
                }
                std::println("");
            }
        }

        const auto& getAllStudents() { return students; }
        const auto& getAllCourses() { return courses; }
        const auto& getAllTeachers() { return teachers; }

};



void Registrar::addStudent(unique_ptr<Student> student) {
    students[student->getStudentId()] = std::move(student);
}


void Registrar::addCourse(unique_ptr<Course> course) {
    courses[course->getCourseId()] = std::move(course);
}


void Registrar::addTeacher(unique_ptr<Teacher> teacher) {
    teachers[teacher->getTeacherId()] = std::move(teacher);
}




    bool Registrar::registerCourse(const std::string& studentId, const std::string& courseId) {
        auto itStudent = students.find(studentId);
        auto itCourse = courses.find(courseId);
        if (itStudent == students.end() || itCourse == courses.end()) return false;

        Student* student = itStudent->second.get();
        Course* course = itCourse->second.get();
        if (course->isFull() || student->hasSelectedCourse(courseId)) return false;


        if (!addEnrollmentToDB(studentId, courseId)) return false;


        bool studentOk = student->selectCourse(courseId);
        bool courseOk = course->enrollStudent();


        if (!(studentOk && courseOk)) {
            removeEnrollmentFromDB(studentId, courseId);
            return false;
        }
        return true;
    }


    bool Registrar::dropCourse(const std::string& studentId, const std::string& courseId) {
        auto itStudent = students.find(studentId);
        auto itCourse = courses.find(courseId);
        if (itStudent == students.end() || itCourse == courses.end()) return false;

        Student* student = itStudent->second.get();
        Course* course = itCourse->second.get();
        if (!student->hasSelectedCourse(courseId)) return false;


        if (!removeEnrollmentFromDB(studentId, courseId)) return false;


        bool studentOk = student->dropCourse(courseId);
        bool courseOk = course->dropStudent();
        return studentOk && courseOk;
    }

vector<const Course*> Registrar::getStudentCourses(const string& studentId) const {
    vector<const Course*> result;
    auto itStudent = students.find(studentId);
    if (itStudent == students.end()) {
        return result;
    }


    for (const auto& courseId : itStudent->second->getSelectedCourses()) {
        auto itCourse = courses.find(courseId);
        if (itCourse != courses.end()) {
            result.push_back(itCourse->second.get());
        }
    }
    return result;
}


vector<const Student*> Registrar::getCourseStudents(const string& courseId) const {
    vector<const Student*> result;
    auto itCourse = courses.find(courseId);
    if (itCourse == courses.end()) {
        return result;
    }


    for (const auto& [studentId, student] : students) {
        if (student->hasSelectedCourse(courseId)) {
            result.push_back(student.get());
        }
    }
    return result;
}



const unordered_map<string, unique_ptr<Course>>& Registrar::getAllCourses() const {
    return courses;
}


const unordered_map<string, unique_ptr<Student>>& Registrar::getAllStudents() const {
    return students;
}


bool Registrar::printStudentRecord(const string& studentId) const {
    auto it = students.find(studentId);
    if (it == students.end()) return false;

    const Student* stu = it->second.get();
    auto courses = getStudentCourses(studentId);

    std::println("-------- 选课记录 --------");
    std::println("学号: {}  姓名: {}  专业: {}  年龄: {}  性别: {}",
                stu->getStudentId(), stu->getName(),
                stu->getMajor(), stu->getAge(), stu->getGender());

    if (courses.empty()) {
        std::println("  当前未选修任何课程。");
    } else {
        std::println("  已选课程 ({} 门):", courses.size());
        for (const Course* c : courses) {
            std::println("    · {:<20} [ID: {}]  容量: {}/{}",
                        c->getCourseName(), c->getCourseId(),
                        c->getCurrentCapacity(), c->getMaxCapacity());
        }
    }
    std::println("--------------------------");
    return true;
}


const Person* Registrar::findPerson(const string& id) const {
   if (auto it = students.find(id); it != students.end()) return it->second.get();
   if (auto it = teachers.find(id); it != teachers.end()) return it->second.get();
   return nullptr;
}
