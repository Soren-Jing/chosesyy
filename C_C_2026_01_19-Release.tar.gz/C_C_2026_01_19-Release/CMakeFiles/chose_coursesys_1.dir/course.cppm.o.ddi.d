CMakeFiles/chose_coursesys_1.dir/course.cppm.o.ddi: \
 /root/demo/chose_coursesys_1/course.cppm /usr/include/stdc-predef.h
