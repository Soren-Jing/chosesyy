# This file is managed by Qt Creator, do not edit!

set("CMAKE_BUILD_TYPE" "Release" CACHE "STRING" "" FORCE)
set("CMAKE_PREFIX_PATH" "/opt/Qt/6.10.0/gcc_64" CACHE "PATH" "" FORCE)
set("CMAKE_CXX_FLAGS_INIT" "" CACHE "STRING" "" FORCE)
set("QT_MAINTENANCE_TOOL" "/opt/Qt/MaintenanceTool" CACHE "FILEPATH" "" FORCE)
set("CMAKE_C_COMPILER" "/usr/bin/gcc" CACHE "FILEPATH" "" FORCE)
set("CMAKE_GENERATOR" "Ninja" CACHE "STRING" "" FORCE)
set("QT_QMAKE_EXECUTABLE" "/opt/Qt/6.10.0/gcc_64/bin/qmake" CACHE "FILEPATH" "" FORCE)
set("CMAKE_COLOR_DIAGNOSTICS" "ON" CACHE "BOOL" "" FORCE)
set("CMAKE_PROJECT_INCLUDE_BEFORE" "/root/demo/chose_coursesys_1/build/C_C_2026_01_19-Release/.qtc/package-manager/auto-setup.cmake" CACHE "FILEPATH" "" FORCE)
set("CMAKE_CXX_COMPILER" "/usr/bin/g++" CACHE "FILEPATH" "" FORCE)